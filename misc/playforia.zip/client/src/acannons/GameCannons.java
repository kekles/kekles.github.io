package acannons;

import acannons.GameApplet;

public class GameCannons extends GameApplet {

    public String getAppletInfo() {
        return "-= ACannons =-\nCopyright (c) 2003-2012 Playforia (www.playforia.info)\nVersion date 2012-07-02\nProgramming: Pasi Laaksonen\nGraphics: Janne Matilainen";
    }
}
