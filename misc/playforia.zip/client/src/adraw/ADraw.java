package adraw;

public class ADraw extends GameApplet {

    public String getAppletInfo() {
        return "-= ADraw =-\nCopyright (c) 2004-2010 Apaja (www.apaja.com)\nProgramming: Pasi Laaksonen";
    }

}
