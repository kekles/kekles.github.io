package agolf2;

import agolf2.Class58_Sub1;
import agolf2.IPanel_Sub33;

class IPanel_Sub33_Sub1 extends IPanel_Sub33 {

    private Class58_Sub1 aClass58_Sub1_4720;
    private static final String aString4721 = "login\t";


    protected IPanel_Sub33_Sub1(Class58_Sub1 var1, int var2, int var3, int var4) {
        super(var1, var2, var3, var4);
        this.aClass58_Sub1_4720 = var1;
    }

    protected void method754(String var1) {
        this.aClass58_Sub1_4720.aClass36_Sub1_3572.method1179("login\t" + var1);
    }

}
