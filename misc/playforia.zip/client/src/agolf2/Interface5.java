package agolf2;


public interface Interface5 {

    void method11(int var1, int var2);

    void method12();

    void method13(int var1, int var2, boolean var3);
}
