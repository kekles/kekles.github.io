package agolf2;

import agolf2.AApplet_Sub3_Sub1;

public class AGolf2 extends AApplet_Sub3_Sub1 {

    public String getAppletInfo() {
        return "-= AGolf2 =-\nCopyright (c) 2007-2012 Playforia (www.playforia.info)\nProgramming: Pasi Laaksonen\nGraphics: Eeva Nikunen";
    }
}
