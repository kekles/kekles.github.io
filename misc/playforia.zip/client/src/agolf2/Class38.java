package agolf2;

public class Class38 {

    private int anInt1013;
    private Block aBlock_1014;
    private Block[] aBlockArray1015;
    private int anInt1016;


    public Class38(int var1) {
        this.anInt1013 = var1;
    }

    public Class38(Block[] var1, int var2) {
        this.anInt1013 = 3;
        this.aBlockArray1015 = var1;
        this.anInt1016 = var2;
    }

    protected int method1223() {
        return this.anInt1013;
    }

    protected void method1224(Block var1) {
        this.aBlock_1014 = var1;
    }

    protected Block method1225() {
        return this.aBlock_1014;
    }

    protected Block[] method1226() {
        return this.aBlockArray1015;
    }

    protected int method1227() {
        return this.anInt1016;
    }
}
