package agolf2;

interface Interface2 {

    void method2(Block var1, boolean var2);
}
