package agolf2;

interface Interface1 {

    void method1(Block var1);
}
