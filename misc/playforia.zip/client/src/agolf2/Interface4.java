package agolf2;


public interface Interface4 {

    void method5(int var1, int var2, int var3, int var4);

    void method6(int var1, int var2, int var3, int var4, boolean var5);

    void method7(int var1, int var2, int var3, int var4, boolean var5);

    void method8(int var1, int var2, int var3, int var4, boolean var5);

    void method9(int var1, boolean var2);

    int method10();
}
