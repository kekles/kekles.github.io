package agolf2;

import java.awt.Image;

public class TrackOverlays {

    protected int[] method1228(int var1) {
        return null;
    }

    protected int[] method1229(int var1) {
        return null;
    }

    protected int[] method1230(int var1) {
        return null;
    }

    public int[] method1231(Image var1, int var2, int var3) {
        return null;
    }

    public Image method1232(int[] var1, int var2, int var3) {
        return null;
    }

    public Image[] getImagesBalls(int var1) {
        return null;
    }

    public void method1234(String var1) {
    }
}
