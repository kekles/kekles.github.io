package agolf2;

import agolf2.IPanel_Sub25;

interface Interface3 {

    void method3(IPanel_Sub25 var1, int var2);

    void method4(IPanel_Sub25 var1, int var2, boolean var3);
}
