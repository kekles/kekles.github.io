package agolf;

public class AGolf extends GameApplet {

    public String getAppletInfo() {
        return "-= AGolf =-\nCopyright (c) 2002-2012 Playforia (www.playforia.info)\nProgramming: Pasi Laaksonen\nGraphics: Janne Matilainen";
    }

}
