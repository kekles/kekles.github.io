package agolf;

import com.aapeli.applet.AApplet;
import com.aapeli.connection.ConnListener;
import com.aapeli.connection.Connection;
import com.aapeli.tools.Tools;

public class Conn implements ConnListener {

    private static final String[] cryptoCmds = new String[68];
    private GameContainer gameContainer;
    private Connection aConnection2371;
    private String aString2372;
    private String aString2373;


    protected Conn(GameContainer var1) {
        this.gameContainer = var1;
        this.aString2372 = this.aString2373 = null;
    }

    public void dataReceived(String var1) {
        try {
            this.handlePacket(var1);
            this.aString2373 = var1;
        } catch (Exception var4) {
            Exception var2 = var4;

            try {
                this.writeData("error-debug\t" + this.gameContainer.gameApplet.method32() + "\t" + var2.toString().trim().replace('\n', '\\') + "\t" + var1.replace('\t', '\\') + "\t" + this.aString2373.replace('\t', '\\') + "\t" + this.aString2372.replace('\t', '\\'));
            } catch (Exception var3) {
                ;
            }

            this.gameContainer.gameApplet.setEndState((Throwable) var4);
            this.aConnection2371.disconnect();
        }
    }

    public void connectionLost(int var1) {
        if (var1 != 2 && var1 != 3) {
            if (var1 == 4) {
                this.gameContainer.gameApplet.setEndState(3);
            }

        } else {
            this.gameContainer.gameApplet.setEndState(2);
        }
    }

    public void notifyConnectionDown() {
    }

    public void notifyConnectionUp() {
    }

    protected boolean method1158() {
        this.aConnection2371 = new Connection(this.gameContainer.gameApplet, this, cryptoCmds);
        return this.aConnection2371.connect();
    }

    protected void method1159() {
        this.gameContainer.gameApplet.setGameState(0);
        this.writeData("version\t" + 35);
    }

    public void writeData(String var1) {
        this.aString2372 = var1;
        this.aConnection2371.writeData(var1);
    }

    protected void method1161() {
        if (this.aConnection2371 != null) {
            this.aConnection2371.disconnect();
        }

    }

    private void handlePacket(String cmd) throws Exception {
        String[] args = Tools.separateString(cmd, "\t");
        if (args[0].equals("error")) {
            if (args[1].equals("vernotok")) {
                this.gameContainer.gameApplet.setEndState(AApplet.END_ERROR_VERSION);
            } else if (args[1].equals("serverfull")) {
                this.gameContainer.gameApplet.setEndState(AApplet.END_ERROR_SERVERFULL);
            }

            this.aConnection2371.disconnect();
        } else if (args[0].equals("versok")) {
            this.writeData("language\t" + this.gameContainer.params.getChatLang());
            String var4 = this.gameContainer.params.getSessionLocale();
            if (var4 != null) {
                this.writeData("sessionlocale\t" + var4);
            }

            this.writeData("logintype\t" + (this.gameContainer.synchronizedTrackTestMode.get() ? "ttm" : (this.gameContainer.gameApplet.hasSession() ? "reg" : "nr")));
        } else if (args[0].equals("basicinfo")) {
            this.gameContainer.gameApplet.setGameSettings(args[1].equals("t"), Integer.parseInt(args[2]), args[3].equals("t"), args[4].equals("t"));
        } else if (args[0].equals("broadcast")) {
            if (this.gameContainer.lobbyPanel != null) {
                this.gameContainer.lobbyPanel.broadcastMessage(args[1]);
            }

            if (this.gameContainer.gamePanel != null) {
                this.gameContainer.gamePanel.broadcastMessage(args[1]);
            }

        }
        else if (args[0].equals("status")) {
            if (args[1].equals("login")) {
                if (args.length == 2) {
                    this.gameContainer.gameApplet.setGameState(1);
                    return;
                }

                byte var3 = 0;
                if (args[2].equals("nickinuse")) {
                    var3 = 4;
                }

                if (args[2].equals("rlf")) {
                    var3 = 5;
                }

                if (args[2].equals("invalidnick")) {
                    var3 = 6;
                }

                if (args[2].equals("forbiddennick")) {
                    var3 = 7;
                }

                this.gameContainer.gameApplet.setGameState(1, var3);
                return;
            }

            if (args[1].equals("lobbyselect")) {
                this.gameContainer.gameApplet.setGameState(2, args.length > 2 ? Integer.parseInt(args[2]) : 0);
                return;
            }

            if (args[1].equals("lobby")) {
                if (args.length == 2) {
                    this.gameContainer.gameApplet.setGameState(3, Integer.MIN_VALUE);
                    return;
                }

                if (args[2].equals("tt")) {
                    this.gameContainer.gameApplet.setGameState(3, -1, args[3].equals("t") ? 1 : 0);
                    return;
                }

                if (!args[2].equals("1") && !args[2].equals("1h")) {
                    if (args[2].equals("2")) {
                        this.gameContainer.gameApplet.setGameState(3, 2);
                        return;
                    }

                    if (args.length == 3) {
                        this.gameContainer.gameApplet.setGameState(3, 3);
                        return;
                    }

                    this.gameContainer.gameApplet.setGameState(3, 3, Integer.parseInt(args[3]));
                    return;
                }

                this.gameContainer.gameApplet.setGameState(3, 1, args[2].equals("1") ? 1 : -1);
                //enables tracklistadmin this.aGameContainer_2370.gameApplet.setGameState(3, -1, 1);
                return;
            }

            if (args[1].equals("game")) {
                this.gameContainer.gameApplet.setGameState(4);
                return;
            }
        }

        if (args[0].equals("lobbyselect")) {
            this.gameContainer.lobbySelectionPanel.handlePacket(args);
        } else if (args[0].equals("lobby")) {
            this.gameContainer.lobbyPanel.handlePacket(args);
        }
        else if (args[0].equals("game")) {
            this.gameContainer.gamePanel.method333(args);
        }
    }

    static {
        cryptoCmds[0] = "status\t";
        cryptoCmds[1] = "basicinfo\t";
        cryptoCmds[2] = "numberofusers\t";
        cryptoCmds[3] = "users\t";
        cryptoCmds[4] = "ownjoin\t";
        cryptoCmds[5] = "joinfromgame\t";
        cryptoCmds[6] = "say\t";
        cryptoCmds[7] = "logintype\t";
        cryptoCmds[8] = "login";
        cryptoCmds[9] = "lobbyselect\t";
        cryptoCmds[10] = "select\t";
        cryptoCmds[11] = "back";
        cryptoCmds[12] = "challenge\t";
        cryptoCmds[13] = "cancel\t";
        cryptoCmds[14] = "accept\t";
        cryptoCmds[15] = "cfail\t";
        cryptoCmds[16] = "nouser";
        cryptoCmds[17] = "nochall";
        cryptoCmds[18] = "cother";
        cryptoCmds[19] = "cbyother";
        cryptoCmds[20] = "refuse";
        cryptoCmds[21] = "afail";
        cryptoCmds[22] = "gsn\t";
        cryptoCmds[23] = "lobby\tnc\t";
        cryptoCmds[24] = "lobby\t";
        cryptoCmds[25] = "lobby";
        cryptoCmds[26] = "tracksetlist\t";
        cryptoCmds[27] = "tracksetlist";
        cryptoCmds[28] = "gamelist\t";
        cryptoCmds[29] = "full\t";
        cryptoCmds[30] = "add\t";
        cryptoCmds[31] = "change\t";
        cryptoCmds[32] = "remove\t";
        cryptoCmds[33] = "gameinfo\t";
        cryptoCmds[34] = "players";
        cryptoCmds[35] = "owninfo\t";
        cryptoCmds[36] = "game\tstarttrack\t";
        cryptoCmds[37] = "game\tstartturn\t";
        cryptoCmds[38] = "game\tstart";
        cryptoCmds[39] = "game\tbeginstroke\t";
        cryptoCmds[40] = "game\tendstroke\t";
        cryptoCmds[41] = "game\tresetvoteskip";
        cryptoCmds[42] = "game\t";
        cryptoCmds[43] = "game";
        cryptoCmds[44] = "quit";
        cryptoCmds[45] = "join\t";
        cryptoCmds[46] = "part\t";
        cryptoCmds[47] = "cspt\t";
        cryptoCmds[48] = "qmpt";
        cryptoCmds[49] = "cspc\t";
        cryptoCmds[50] = "jmpt\t";
        cryptoCmds[51] = "tracklist\t";
        cryptoCmds[52] = "Tiikoni";
        cryptoCmds[53] = "Leonardo";
        cryptoCmds[54] = "Ennaji";
        cryptoCmds[55] = "Hoeg";
        cryptoCmds[56] = "Darwin";
        cryptoCmds[57] = "Dante";
        cryptoCmds[58] = "ConTrick";
        cryptoCmds[59] = "Dewlor";
        cryptoCmds[60] = "Scope";
        cryptoCmds[61] = "SuperGenuis";
        cryptoCmds[62] = "Zwan";
        cryptoCmds[63] = "\tT !\t";
        cryptoCmds[64] = "\tcr\t";
        cryptoCmds[65] = "rnop";
        cryptoCmds[66] = "nop\t";
        cryptoCmds[67] = "error";
    }
}
