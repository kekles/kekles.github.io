package apool;

public class GamePool extends GameApplet {

    public String getAppletInfo() {
        return "-= APool =-\nCopyright (c) 2002-2012 Playforia (www.playforia.info)\nVersion date 2012-06-26\nProgramming: Pasi Laaksonen\nGraphics: Janne Puonti, Janne Matilainen";
    }
}
