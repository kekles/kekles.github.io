package apool;

import apool.GlossyButton_Sub2;

class GlossyButton_Sub2_Sub2 extends GlossyButton_Sub2 {

    protected GlossyButton_Sub2_Sub2(String var1, int var2) {
        super(var1, var2);
        this.setColor(1);
    }

    protected boolean method2880() {
        return true;
    }

    protected boolean method2881() {
        return true;
    }
}
