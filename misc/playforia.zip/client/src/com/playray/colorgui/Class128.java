package com.playray.colorgui;

import java.awt.Color;
import java.awt.Font;

class Class128 {

    protected static final String aString1997 = "Dialog";
    protected static final Font aFont1998 = new Font("Dialog", 0, 12);
    protected static final Color aColor1999 = new Color(0, 0, 0);


}
