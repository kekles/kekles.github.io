package com.playray.client;


public interface SwingUpdateTarget {

    void updateUI(Object var1);
}
