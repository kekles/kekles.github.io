package com.playray.client;


public interface InputTextFieldListener {

    void startedTyping();

    void clearedField();

    void enterPressed();
}
