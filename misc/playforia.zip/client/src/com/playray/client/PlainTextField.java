package com.playray.client;

import java.awt.Graphics;
import javax.swing.JTextField;

public class PlainTextField extends JTextField {

    public void paintBorder(Graphics var1) {
    }
}
