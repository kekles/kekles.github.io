package com.aapeli.client;


public interface InputTextFieldListener {

    void startedTyping();

    void clearedField();

    void enterPressed();
}
