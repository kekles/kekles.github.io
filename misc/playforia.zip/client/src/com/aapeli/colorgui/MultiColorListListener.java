package com.aapeli.colorgui;

/**
 * Playforia
 * 7.7.2013
 */
public interface MultiColorListListener {

    public void mouseDoubleClicked(MultiColorListItem clickedItem);
}
