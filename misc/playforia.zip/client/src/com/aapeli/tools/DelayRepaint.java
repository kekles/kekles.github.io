package com.aapeli.tools;

import com.aapeli.tools.QuickTimer;
import com.aapeli.tools.QuickTimerListener;

import java.awt.Component;

public class DelayRepaint implements QuickTimerListener {

    private Component aComponent2593;


    public DelayRepaint(Component var1) {
        this(var1, 500);
    }

    public DelayRepaint(Component var1, int var2) {
        this.aComponent2593 = var1;
        new QuickTimer(var2, this);
    }

    public void qtFinished() {
        this.aComponent2593.repaint();
    }
}
