package com.aapeli.tools;


public interface Sortable {

    int compareTo(Sortable var1);
}
