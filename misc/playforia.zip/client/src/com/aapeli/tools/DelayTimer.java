package com.aapeli.tools;

import com.aapeli.tools.Tools;

public class DelayTimer {

    private double aDouble1713;
    private int anInt1714;
    private int anInt1715;
    private long aLong1716;
    private long aLong1717;
    private long aLong1718;
    private long aLong1719;
    private boolean aBoolean1720;
    private static final String[] aStringArray1721 = new String[4];


    public DelayTimer(int var1) {
        this(var1, false);
    }

    public DelayTimer(int var1, boolean var2) {
        this.aDouble1713 = 1000.0D / (double) var1;
        this.anInt1714 = this.anInt1715 = 0;
        this.aLong1716 = this.aLong1719 = this.aLong1718 = 0L;
        this.aLong1717 = System.currentTimeMillis();
        this.aBoolean1720 = var2;
    }

    public synchronized boolean doDelay() {
        if (this.aLong1718 > 0L) {
            return false;
        } else {
            ++this.anInt1714;
            int var1 = (int) ((double) (this.aLong1717 + this.aLong1719) + (double) this.anInt1714 * this.aDouble1713 - (double) System.currentTimeMillis());
            if ((double) var1 < (double) (this.aLong1716 / (long) this.anInt1714) - this.aDouble1713 * 5.0D) {
                if (this.aBoolean1720) {
                    System.out.println("DelayTimer.doDelay(): Delay skipped (delay=" + var1 + ")");
                }

                this.aLong1719 -= (long) var1;
                var1 = 0;
            }

            double var2 = this.aDouble1713 * 10.0D;
            if ((double) var1 > var2) {
                if (this.aBoolean1720) {
                    System.out.println("DelayTimer.doDelay(): Delay limited (delay=" + var1 + ")");
                }

                this.aLong1719 -= (long) ((double) var1 - var2);
                var1 = (int) (var2 + 0.5D);
            }

            this.anInt1715 = var1;
            this.aLong1716 += (long) var1;
            if (var1 > 0) {
                Tools.sleep((long) var1);
                return true;
            } else {
                return false;
            }
        }
    }

    public synchronized void startPause() {
        if (this.aBoolean1720) {
            System.out.println("DelayTimer.startPause()");
        }

        if (this.aLong1718 <= 0L) {
            this.aLong1718 = System.currentTimeMillis();
        }
    }

    public synchronized void endPause() {
        if (this.aBoolean1720) {
            System.out.println("DelayTimer.endPause()");
        }

        if (this.aLong1718 > 0L) {
            this.aLong1719 += System.currentTimeMillis() - this.aLong1718;
            this.aLong1718 = 0L;
        }
    }

    public int getLastDelay() {
        return this.anInt1714 == 0 ? 0 : this.anInt1715;
    }

    public int getAverageDelay() {
        return this.anInt1714 == 0 ? 0 : (int) (this.aLong1716 / (long) this.anInt1714);
    }

    static {
        aStringArray1721[0] = "DelayTimer.endPause()";
        aStringArray1721[1] = "DelayTimer.startPause()";
        aStringArray1721[2] = "DelayTimer.doDelay(): Delay skipped (delay=";
        aStringArray1721[3] = "DelayTimer.doDelay(): Delay limited (delay=";
    }
}
