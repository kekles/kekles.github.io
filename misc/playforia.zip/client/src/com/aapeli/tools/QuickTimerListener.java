package com.aapeli.tools;


public interface QuickTimerListener {

    void qtFinished();
}
