package com.aapeli.credit;


public interface BuyCreditsHandler {

    void quitToBuyCredits();
}
