package com.aapeli.applet;

import com.aapeli.client.Parameters;
import com.aapeli.client.TextManager;
import com.aapeli.colorgui.RoundButton;
import com.aapeli.tools.Tools;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Panel_Sub22 extends Panel implements Runnable, ActionListener {

    private static final Font aFont578;
    private static final Font aFont579;
    private AApplet anAApplet580;
    private Parameters aParameters581;
    private TextManager aTextManager582;
    private String aString583;
    private double aDouble584;
    private double aDouble585;
    private double aDouble586;
    private int anInt587;
    private boolean aBoolean588;
    private boolean aBoolean589;
    private boolean aBoolean590;
    private boolean aBoolean591;
    private Image anImage592;
    private Graphics aGraphics593;
    private AdCanvas aAdCanvas__594;
    private boolean aBoolean595;
    private RoundButton aRoundButton596;
    private RoundButton aRoundButton597;
    private int anInt598;
    private static final String[] aStringArray599 = new String[3];


    protected Panel_Sub22(AApplet var1) {
        this.anAApplet580 = var1;
        this.aString583 = null;
        this.aDouble584 = this.aDouble585 = 0.0D;
        this.aDouble586 = 0.0018D;
        this.anInt587 = 50;
        this.aBoolean590 = false;
        this.aBoolean591 = false;
        this.aBoolean588 = true;
        this.aBoolean589 = true;
        this.anInt598 = -1;
    }

    public void paint(Graphics var1) {
        this.update(var1);
    }

    public synchronized void update(Graphics var1) {
        if (!this.aBoolean591) {
            AApplet var2 = this.anAApplet580;
            if (var2 != null) {
                int var3 = var2.anInt2540;
                int var4 = var2.anInt2541;
                if (this.anImage592 == null) {
                    this.anImage592 = this.createImage(var3, var4);
                    this.aGraphics593 = this.anImage592.getGraphics();
                    this.aBoolean588 = true;
                }

                Color var5 = this.getBackground();
                if (var5.equals(Color.black)) {
                    var5 = new Color(24, 24, 24);
                }

                boolean var6 = this.aBoolean588;
                this.aBoolean588 = false;
                if (var6) {
                    this.method474(this.aGraphics593, var5, 0, 32, 0, var4, 0, var3, this.aBoolean589);
                    this.aBoolean589 = false;
                    if (this.aString583 != null && this.anInt598 == -1) {
                        this.aGraphics593.setColor(this.getForeground());
                        this.method477(this.aGraphics593, aFont578, this.aString583);
                    }

                    if (this.aAdCanvas__594 != null) {
                        this.aAdCanvas__594.repaint();
                    }
                }

                if (this.anInt598 == -1) {
                    this.method474(this.aGraphics593, Color.white, 0, 48, 25, 40, 5, var3 - 5, true);
                    int var7 = (int) ((double) (var3 - 10) * this.aDouble585);
                    if (var7 > 0) {
                        this.method474(this.aGraphics593, Color.green, 144, 144, 25, 40, 5, 5 + var7, true);
                    }

                    this.aGraphics593.setColor(Color.black);
                    this.aGraphics593.drawRect(5, 25, var3 - 10 - 1, 14);
                }

                var1.drawImage(this.anImage592, 0, 0, this);
            }
        }
    }

    public void setBackground(Color var1) {
        super.setBackground(var1);
        this.aBoolean588 = true;
        this.repaint();
    }

    public void run() {
        do {
            try {
                Thread.sleep((long) this.anInt587);
            } catch (InterruptedException var3) {
                ;
            }

            if (this.aBoolean591) {
                return;
            }

            boolean var1 = false;
            if (this.aDouble585 < this.aDouble584) {
                this.aDouble585 += this.method478();
                if (this.aDouble585 > 1.0D) {
                    this.aDouble585 = 1.0D;
                }

                var1 = true;
            }

            if (this.aDouble584 >= 1.0D && this.anAApplet580.isDebug()) {
                this.aDouble585 = 1.0D;
                var1 = true;
            }

            if (var1) {
                this.repaint();
            }
        } while (this.aDouble585 < 1.0D);

        this.aBoolean590 = true;
    }

    public void actionPerformed(ActionEvent var1) {
        if (var1.getSource() == this.aRoundButton596) {
            this.anInt598 = 1;
        } else {
            this.anAApplet580.setEndState(8);
            this.aParameters581.showCreditPurchasePage(false);
        }

    }

    protected void method462(Parameters var1, TextManager var2) {
        this.aParameters581 = var1;
        this.aTextManager582 = var2;
    }

    protected void method463() {
        Thread var1 = new Thread(this);
        var1.start();
    }

    protected void method464(String var1) {
        this.aString583 = var1;
        this.aBoolean588 = true;
        this.repaint();
    }

    protected void method465(double var1) {
        this.aDouble584 += var1;
    }

    protected void method466(AdCanvas var1, boolean var2) {
        this.setLayout((LayoutManager) null);
        int var3 = this.anAApplet580.anInt2540 - 5 - 5;
        int var4 = this.anAApplet580.anInt2541 - 5 - 5 - 40;
        Dimension var5 = var1.getSize();
        var1.setLocation(5 + var3 / 2 - var5.width / 2, 45 + var4 / 2 - var5.height / 2);
        this.add(var1);
        var1.method214(this);
        this.aAdCanvas__594 = var1;
        this.aBoolean595 = var2;
    }

    protected void method467(double var1) {
        this.aDouble584 = var1;
    }

    protected void method468(double var1) {
        this.aDouble586 *= var1;
    }

    protected Image method469() {
        return this.anImage592;
    }

    protected void method470() {
        this.anInt587 = 25;
    }

    protected boolean method471() {
        return this.aBoolean590;
    }

    protected void method472() {
        if (this.aAdCanvas__594 != null) {
            if (this.aBoolean595) {
                this.anInt598 = 0;
                this.aBoolean588 = true;
                this.repaint();
                short var1 = 300;
                int var2 = (this.anAApplet580.anInt2540 - 25 - 15 - 15 - 25) / 2;
                int var3 = Math.min(var1, var2);
                this.aRoundButton596 = new RoundButton(this.aTextManager582.getShared("Loader_Button_StartGame"));
                this.aRoundButton596.setBounds(this.anAApplet580.anInt2540 / 2 + 15, 10, var3, 35);
                this.aRoundButton596.setBackground(new Color(96, 224, 96));
                this.aRoundButton596.setForeground(Color.black);
                this.aRoundButton596.setFont(aFont579);
                this.aRoundButton596.addActionListener(this);
                this.add(this.aRoundButton596);
                if (this.aParameters581.isCreditPurchasePageAvailable()) {
                    this.aRoundButton597 = new RoundButton(this.aTextManager582.getShared("Loader_Button_MorePaymentOptions"));
                    this.aRoundButton597.setBounds(this.anAApplet580.anInt2540 / 2 - 15 - var3, 10, var3, 35);
                    this.aRoundButton597.setBackground(new Color(96, 96, 255));
                    this.aRoundButton597.setForeground(Color.black);
                    this.aRoundButton597.setFont(aFont579);
                    this.aRoundButton597.addActionListener(this);
                    this.add(this.aRoundButton597);
                }

                do {
                    Tools.sleep(25L);
                } while (this.anInt598 == 0 && !this.aBoolean591);

                this.remove(this.aRoundButton596);
            }
        }
    }

    protected synchronized void method473() {
        this.aBoolean591 = true;
        if (this.aAdCanvas__594 != null) {
            this.remove(this.aAdCanvas__594);
            this.aAdCanvas__594.method217();
            this.aAdCanvas__594 = null;
        }

        this.aString583 = null;
        if (this.aGraphics593 != null) {
            this.aGraphics593.dispose();
            this.aGraphics593 = null;
        }

        if (this.anImage592 != null) {
            this.anImage592.flush();
            this.anImage592 = null;
        }

        this.anAApplet580 = null;
    }

    private void method474(Graphics var1, Color var2, int var3, int var4, int var5, int var6, int var7, int var8, boolean var9) {
        int var10 = var2.getRed();
        int var11 = var2.getGreen();
        int var12 = var2.getBlue();
        int var13 = var10 + var3;
        int var14 = var11 + var3;
        int var15 = var12 + var3;
        int var16 = var10 - var4;
        int var17 = var11 - var4;
        int var18 = var12 - var4;
        if (var13 > 255) {
            var13 = 255;
        }

        if (var14 > 255) {
            var14 = 255;
        }

        if (var15 > 255) {
            var15 = 255;
        }

        if (var16 < 0) {
            var16 = 0;
        }

        if (var17 < 0) {
            var17 = 0;
        }

        if (var18 < 0) {
            var18 = 0;
        }

        if (var9) {
            this.method475(var1, var5, var6, var7, var8, var13, var16, var14, var17, var15, var18);
        } else {
            this.method476(var1, var5, var6, var7, var8, var13, var16, var14, var17, var15, var18);
        }

    }

    private void method475(Graphics var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
        for (int var17 = var2; var17 < var3; ++var17) {
            double var12 = 1.0D * (double) (var17 - var2) / (double) (var3 - var2);
            int var14 = (int) ((double) var6 + (double) (var7 - var6) * var12);
            int var15 = (int) ((double) var8 + (double) (var9 - var8) * var12);
            int var16 = (int) ((double) var10 + (double) (var11 - var10) * var12);
            var1.setColor(new Color(var14, var15, var16));
            var1.drawLine(var4, var17, var5 - 1, var17);
        }

    }

    private void method476(Graphics var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
        int var20 = -1;

        for (int var21 = var2; var21 < var3; ++var21) {
            double var12 = 1.0D * (double) (var21 - var2) / (double) (var3 - var2);

            for (int var22 = var4; var22 < var5; ++var22) {
                double var14;
                if (var22 == var4) {
                    var14 = 0.0D;
                } else {
                    var14 = Math.random() * 1.98D - 0.99D;
                }

                int var16 = (int) ((double) var6 + (double) (var7 - var6) * var12 + var14);
                int var17 = (int) ((double) var8 + (double) (var9 - var8) * var12 + var14);
                int var18 = (int) ((double) var10 + (double) (var11 - var10) * var12 + var14);
                int var19 = var16 * 256 * 256 + var17 * 256 + var18;
                if (var22 == var4) {
                    var20 = var19;
                    var1.setColor(new Color(var19));
                    var1.drawLine(var4, var21, var5, var21);
                } else if (var19 != var20) {
                    var1.setColor(new Color(var19));
                    var1.fillRect(var22, var21, 1, 1);
                }
            }
        }

    }

    private void method477(Graphics var1, Font var2, String var3) {
        while (this.getFontMetrics(var2).stringWidth(var3) > this.anAApplet580.anInt2540 - 12) {
            var2 = new Font(var2.getName(), var2.getStyle(), var2.getSize() - 1);
        }

        var1.setFont(var2);
        var1.drawString(this.aString583, 6, 19);
    }

    private double method478() {
        if (this.aAdCanvas__594 == null) {
            return this.aDouble586;
        } else {
            int var1 = this.aAdCanvas__594.method215();
            if (var1 <= 0) {
                return this.aDouble586;
            } else {
                double var2 = 1.0D - this.aDouble585;
                double var4 = var2 * (double) this.anInt587 / (double) var1;
                return var4 > this.aDouble586 ? this.aDouble586 : var4;
            }
        }
    }

    static {
        aStringArray599[0] = "Loader_Button_MorePaymentOptions";
        aStringArray599[1] = "Loader_Button_StartGame";
        aStringArray599[2] = "Dialog";
        aFont578 = new Font("Dialog", 0, 14);
        aFont579 = new Font("Dialog", 1, 20);
    }
}
