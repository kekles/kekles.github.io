package com.aapeli.applet;

import com.aapeli.client.StringDraw;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.StringTokenizer;

class Class76 {

    private int anInt1303;
    private int anInt1304;
    private int anInt1305;
    private Color aColor1306;
    private Color aColor1307;
    private String aString1308;
    private Font aFont1309;
    private int anInt1310;
    private static final String[] aStringArray1311 = new String[3];


    private Class76(int var1, int var2, int var3, int var4, Color var5, Color var6, int var7, boolean var8, String var9) {
        this.anInt1303 = var1;
        this.anInt1304 = var2;
        this.anInt1305 = var4;
        this.aColor1306 = var5;
        this.aColor1307 = var6;
        this.aString1308 = var9;
        this.aFont1309 = new Font("Dialog", var8 ? 1 : 0, var7);
        this.anInt1310 = -1;
        if (var3 > 0) {
            this.anInt1310 = 1;
        } else if (var3 == 0) {
            this.anInt1310 = 0;
        }

    }

    protected static Class76 method1547(String var0) {
        try {
            int var1 = var0.indexOf(58);
            String var2 = var0.substring(var1 + 1);
            StringTokenizer var3 = new StringTokenizer(var0.substring(0, var1), ",");
            int var4 = Integer.parseInt(var3.nextToken());
            int var5 = Integer.parseInt(var3.nextToken());
            int var6 = Integer.parseInt(var3.nextToken());
            int var7 = Integer.parseInt(var3.nextToken());
            Color var8 = method1549(var3.nextToken(), false);
            Color var9 = method1549(var3.nextToken(), true);
            int var10 = Integer.parseInt(var3.nextToken());
            boolean var11 = var3.nextToken().equalsIgnoreCase("bold");
            Class76 var12 = new Class76(var4, var5, var6, var7, var8, var9, var10, var11, var2);
            return var12;
        } catch (Exception var13) {
            return null;
        }
    }

    protected void method1548(Graphics var1) {
        var1.setFont(this.aFont1309);
        var1.setColor(this.aColor1306);
        if (this.anInt1305 > 0) {
            StringDraw.drawOutlinedStringWithMaxWidth(var1, this.aColor1307, this.aString1308, this.anInt1303, this.anInt1304, this.anInt1310, this.anInt1305);
        } else {
            StringDraw.drawOutlinedString(var1, this.aColor1307, this.aString1308, this.anInt1303, this.anInt1304, this.anInt1310);
        }

    }

    private static Color method1549(String var0, boolean var1) throws Exception {
        try {
            if (var0.startsWith("#")) {
                var0 = var0.substring(1);
            } else if (var0.startsWith("0x")) {
                var0 = var0.substring(2);
            }

            int var2 = Integer.parseInt(var0, 16);
            if (var2 < 0) {
                throw new Exception();
            } else {
                Color var3 = new Color(var2);
                return var3;
            }
        } catch (Exception var4) {
            if (!var1) {
                throw var4;
            } else {
                return null;
            }
        }
    }

    static {
        aStringArray1311[0] = "0x";
        aStringArray1311[1] = "bold";
        aStringArray1311[2] = "Dialog";
    }
}
