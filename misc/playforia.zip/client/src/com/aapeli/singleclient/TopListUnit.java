package com.aapeli.singleclient;

import java.util.StringTokenizer;

public final class TopListUnit {

    private String aString1706;
    private long aLong1707;
    private String aString1708;
    private String aString1709;
    private String[] aStringArray1710;
    private int anInt1711;
    public static boolean aBoolean1712;


    protected TopListUnit(StringTokenizer var1, int var2) {
        this.aString1706 = var1.nextToken();
        this.aLong1707 = Long.parseLong(var1.nextToken());
        this.aString1708 = var1.nextToken();
        this.aString1709 = var1.nextToken();
        this.anInt1711 = var2;
        this.aStringArray1710 = new String[var2];

        for (int var3 = 0; var3 < var2; ++var3) {
            this.aStringArray1710[var3] = var1.nextToken();
        }

    }

    public String getName() {
        return this.aString1706;
    }

    public long getTime() {
        return this.aLong1707;
    }

    public String getColumn(int var1) {
        return this.aStringArray1710[var1];
    }

    public String getBitmapUrlSmall() {
        return this.aString1708;
    }

    public String getBitmapUrlMedium() {
        return this.aString1709;
    }

    protected int method1870() {
        return this.anInt1711;
    }
}
