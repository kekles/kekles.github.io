package com.aapeli.singleclient;


public interface SingleGame {

    boolean isDebugMode();

    void connectionError();
}
