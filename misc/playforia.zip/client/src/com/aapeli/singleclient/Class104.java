package com.aapeli.singleclient;

import java.util.Hashtable;

class Class104 {

    private Hashtable aHashtable1697 = new Hashtable();


    protected boolean method1848(String var1, String var2) {
        if (var2 == null) {
            return false;
        } else {
            String var3 = this.method1849(var1);
            if (var3 != null && var3.equals(var2)) {
                return false;
            } else {
                this.aHashtable1697.put(var1.toLowerCase(), var2);
                return true;
            }
        }
    }

    protected String method1849(String var1) {
        return (String) ((String) this.aHashtable1697.get(var1.toLowerCase()));
    }
}
