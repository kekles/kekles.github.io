package com.aapeli.tilt;

import java.awt.Color;
import java.awt.TextField;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class MoneyTextField extends TextField implements FocusListener {

    private static final Color aColor732 = Color.white;
    private static final Color aColor733 = Color.black;
    private int anInt734;
    private int anInt735;
    public static int anInt736;
    private static final String aString737 = "00";


    public MoneyTextField(int var1, int var2, int var3) {
        this.anInt734 = var1;
        this.anInt735 = var2;
        this.setText(getValueString(this.method970(var3)));
        this.setBackground(aColor732);
        this.setForeground(aColor733);
        this.setEditable(true);
        this.addFocusListener(this);
    }

    public void focusGained(FocusEvent var1) {
    }

    public void focusLost(FocusEvent var1) {
        this.setText(getValueString(this.method970(this.method971(this.getText()))));
    }

    public static String getValueString(int var0) {
        int var1 = var0 / 100;
        int var2 = var0 % 100;
        return var1 + "," + (var2 < 10 ? "0" : "") + var2;
    }

    public int getAmount() {
        return this.method970(this.method971(this.getText()));
    }

    private int method970(int var1) {
        if (var1 < this.anInt734) {
            var1 = this.anInt734;
        }

        if (var1 > this.anInt735) {
            var1 = this.anInt735;
        }

        return var1;
    }

    private int method971(String var1) {
        var1 = this.method972(var1);
        if (var1 == null) {
            return 0;
        } else {
            int var2 = var1.indexOf(44);
            if (var2 == -1) {
                return this.method973(var1 + "00");
            } else {
                String var3 = var1.substring(0, var2);
                String var4 = var1.substring(var2 + 1);
                int var5 = var4.length();
                if (var5 > 2) {
                    return 0;
                } else {
                    var1 = var3;
                    if (var5 == 0) {
                        var1 = var3 + "00";
                    } else if (var5 == 1) {
                        var1 = var3 + var4 + "0";
                    } else if (var5 == 2) {
                        var1 = var3 + var4;
                    }

                    return this.method973(var1);
                }
            }
        }
    }

    private String method972(String var1) {
        int var2 = var1.length();
        StringBuffer var3 = new StringBuffer(var2);
        boolean var4 = false;

        for (int var6 = 0; var6 < var2; ++var6) {
            char var5 = var1.charAt(var6);
            if (var5 == 46) {
                var5 = 44;
            }

            if (var5 == 44) {
                if (var4) {
                    return null;
                }

                var4 = true;
                var3.append(var5);
            } else if (var5 != 32) {
                if (var5 < 48 || var5 > 57) {
                    return null;
                }

                var3.append(var5);
            }
        }

        return var3.toString();
    }

    private int method973(String var1) {
        try {
            return Integer.parseInt(var1);
        } catch (NumberFormatException var3) {
            return 0;
        }
    }

}
